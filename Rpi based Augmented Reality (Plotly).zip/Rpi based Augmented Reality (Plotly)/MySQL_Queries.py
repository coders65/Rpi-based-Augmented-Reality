from mariadb import connect, Error
import cv2
#import MySQL_Queries1

def get_sequence(tablename,sequence):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality",
                # auth_plugin='mysql_native_password'
        ) as connection:
            with connection.cursor() as cursor:
                #print("SELECT subVariantName FROM "+tablename+" WHERE sequencenumber = "+"'"+sequence+"'")
                cursor.execute("SELECT subVariantName FROM "+tablename+" WHERE sequencenumber = "+"'"+sequence+"'")
                #value = cursor.fetchone()[0]
                value = cursor.fetchone()
                if value is not None:
                    value = value[0]
                return value


    except Error as e:
        print(e)

def remove_table(tablename):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                #print ("DROP TABLE "+tablename)
                cursor.execute("DROP TABLE "+tablename)

    except Error as e:
        print(e)

def get_subVariant_names(table_name):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                #print("SELECT subVariantName FROM "+table_name+" WHERE mainvariantName =",table_name)
                cursor.execute("SELECT subVariantName FROM "+table_name+" WHERE mainvariantName = " + "'"+table_name+"'")
                result = cursor.fetchall()
                variantnames = []
                for variantname in result:
                    variantnames.append(variantname[0])
                #print(variantnames)
                return variantnames
    except Error as e:
        print(e)

def get_table_names():
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                #print("SHOW TABLES")
                cursor.execute("SHOW TABLES")
                result = cursor.fetchall()
                tablenames = []
                for tablename in result:
                    tablenames.append(tablename[0])
                #print(tablenames)
                return tablenames
    except Error as e:
        print(e)

def create_Database(database_name):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658'
        ) as connection:
            with connection.cursor() as cursor:
                #print("CREATE DATABASE " + database_name)
                cursor.execute("CREATE DATABASE " + database_name)
                connection.commit()
    except Error as e:
        print(e)

def create_table_db(tablename):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                #print("CREATE TABLE " + tablename + " (id INT AUTO_INCREMENT PRIMARY KEY, mainvariantName VARCHAR(100), subVariantName VARCHAR(100), masterimagepath VARCHAR(500), templateimagepath VARCHAR(500), maskingarea VARCHAR(100), scorevalue VARCHAR(100), resultselection VARCHAR(100), sequencenumber VARCHAR(100))")
                cursor.execute(
                    "CREATE TABLE " + tablename + " (id INT AUTO_INCREMENT PRIMARY KEY, mainvariantName VARCHAR(100), subVariantName VARCHAR(100), masterimagepath VARCHAR(500), templateimagepath VARCHAR(500), maskingarea VARCHAR(100), scorevalue VARCHAR(100), resultselection VARCHAR(100), voicecommand VARCHAR(500), sequencenumber VARCHAR(100))")
                connection.commit()
    except Error as e:
        print(e)


def insert_db(tablename, columnnames, data):
    query = "INSERT INTO " + tablename + " (" + columnnames[0] + "," + columnnames[1] + "," + columnnames[
        2] + ","+ columnnames[3] + ","+ columnnames[4] + "," + columnnames[5] + ","+ columnnames[6] + ","+ columnnames[7] + ","+ columnnames[8] + ")"+" VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                # #print("INSERT INTO " + tablename + " " + columnnames + " VALUES " + str(data))
                # cursor.execute("INSERT INTO " + tablename + " " + columnnames + " VALUES " + str(data))
                #print(data)
                insert = data
                #print(insert)
                cursor.execute(query, insert)
                connection.commit()
    except Error as e:

        print(e)


def update_db(tablename,subvariant, columnname, value):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "UPDATE " + tablename + " SET " +columnname +" = " + "'" + value + "'" + " WHERE " +
                    " subVariantName = " + "'" + subvariant + "'")
                connection.commit()
    except Error as e:
        print(e)


def select_from_db(tablename, subVariantName,columnname):
    query = "SELECT "+columnname+" FROM " + tablename + " WHERE subVariantName = %s AND mainVariantName = %s"
    try:
        connection1 = connect()
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                insert = (subVariantName, tablename)
                #print(insert)
                #print(query, insert)
                cursor.execute(query, insert)
                value = cursor.fetchone()[0]
                return value



    except Error as e:
        print(e)


def get_rowIndex(tablename, value):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT COUNT(*) FROM " + tablename + " WHERE " + "mainvariantName= " + "'" + value + "'")
                result = cursor.fetchone()
                rowcount = result[0]
                #print(rowcount)
                return rowcount

    except Error as e:
        print(e)


def delete_table_data(tablename, value, length):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM " + tablename + " WHERE " + "mainvariantName= " + "'" + value + "'")
                #print("ALTER TABLE " + tablename + " AUTO_INCREMENT = " + length)
                #cursor.execute("ALTER TABLE " + tablename + " AUTO_INCREMENT = " + length)
                connection.commit()
                cursor.close()
    except Error as e:
        print(e)
