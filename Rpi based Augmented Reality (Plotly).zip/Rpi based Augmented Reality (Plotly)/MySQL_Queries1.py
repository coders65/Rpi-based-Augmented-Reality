from mariadb import connect, Error
import cv2
#import new_22

def create_Database(database_name):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658'
        ) as connection:
            with connection.cursor() as cursor:
                #print("CREATE DATABASE " + database_name)
                cursor.execute("CREATE DATABASE " + database_name)
                connection.commit()
    except Error as e:
        print(e)
#create_Database("augmented_reality")

def create_table_db(tablename):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                #print("CREATE TABLE " + tablename + " (id INT AUTO_INCREMENT PRIMARY KEY, mainvariantName VARCHAR(100), subVariantName VARCHAR(100), masterimagepath VARCHAR(500), templateimagepath VARCHAR(500), maskingarea VARCHAR(100), scorevalue VARCHAR(100), resultselection VARCHAR(100), sequencenumber VARCHAR(100))")
                cursor.execute(
                    "CREATE TABLE " + tablename + " (id INT AUTO_INCREMENT PRIMARY KEY, mainvariantName VARCHAR(100), subVariantName VARCHAR(100), masterimagepath VARCHAR(500), templateimagepath VARCHAR(500), maskingarea VARCHAR(100), scorevalue VARCHAR(100), resultselection VARCHAR(100), voicecommand VARCHAR(500), sequencenumber VARCHAR(100))")
                #print ('created')
                connection.commit()
                #print('create table exit')
    except Error as e:
        print(e)
#create_Database("augmented_reality")

def insert_db(tablename, columnnames, data):
    query = "INSERT INTO " + tablename + " (" + columnnames[0] + "," + columnnames[1] + "," + columnnames[
        2] + ","+ columnnames[3] + ","+ columnnames[4] + "," + columnnames[5] + "," + columnnames[6] + ","+ columnnames[7] + ","+ columnnames[8] + ")"+" VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                # #print("INSERT INTO " + tablename + " " + columnnames + " VALUES " + str(data))
                # cursor.execute("INSERT INTO " + tablename + " " + columnnames + " VALUES " + str(data))
                #print(data)
                insert = data
                #print(insert)
                cursor.execute(query, insert)
                connection.commit()
    except Error as e:
        print(e)


def update_db(tablename, subVariantName, mainVariantName, id):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "UPDATE " + tablename + " SET subVariantName = " + "'" + subVariantName + "'" + " WHERE " +
                    " mainVariantName = " + "'" + mainVariantName + "'" + " AND id =" + id)
                connection.commit()
    except Error as e:
        print(e)


def select_from_db(tablename, subVariantName):
    query = "SELECT masterimagepath FROM " + tablename + " WHERE subVariantName = %s AND mainVariantName = %s"
    try:
        connection1 = connect()
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                insert = (subVariantName, tablename)
                #print(insert)
                #print(query, insert)
                cursor.execute(query, insert)
                image = cursor.fetchone()[1, 2]
                #list1 = [1, 2]
                image.sort()
                temp = image[0]
                ##print(temp)
                #print(image)
                fp = open('C:/Users/Logeshwaran/AppData/Local/Programs/Python/Python311/images1.jpg', 'wb')
                fp.write(image)
                image1 = cv2.imread('C:/Users/Logeshwaran/AppData/Local/Programs/Python/Python311/images.jpg', 0)
                return image1

    except Error as e:
        print(e)


def get_rowIndex(tablename, value):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT COUNT(*) FROM " + tablename + " WHERE " + "mainvariantName= " + "'" + value + "'")
                result = cursor.fetchone()
                rowcount = result[0]
                #print(rowcount)
                return rowcount

    except Error as e:
        print(e)


def delete_table_data(tablename, value, length):
    try:
        with connect(
                host="localhost",
                user='root',
                password='#Logeshwaran658',
                database="augmented_reality"
        ) as connection:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM " + tablename + " WHERE " + "mainvariantName= " + "'" + value + "'")
                #print("ALTER TABLE " + tablename + " AUTO_INCREMENT = " + length)
                cursor.execute("ALTER TABLE " + tablename + " AUTO_INCREMENT = " + length)
                connection.commit()
    except Error as e:
        print(e)

def select_from_db(mainVariant, SubVariant, index):
    try:
        image1 = select_from_db(mainVariant, SubVariant, index)
        #list1 = [1, 2]
        image1.sort()
        i = image1[0]
        #print(i)
        i = 0
    except:
        print("Error occured while retrieving data")
    finally:
        return image1

try:

    # Table column structure
    columnName = ('mainvariantName', 'subVariantName', 'masterimagepath')

    mainVariant = "bumpereol"
    # Creare table in db
    create_table_db(mainVariant)

    SubVariant = ["analog", "digital", "blind audit", "vision test", "eol", "test"]
    blob_value = "C:/Users/Logeshwaran/AppData/Local/Programs/Python/Python311/images.jpg"

    rowCount = get_rowIndex(mainVariant, mainVariant)
    #print('Row Count: ' + str(rowCount))

    #image1 = select_from_db(mainVariant, SubVariant[0],[1])
    #list1 = [1, 2]
    #image1.sort()
    #i = image1[0]
    ##print(i)
    i = 0

    if rowCount == len(SubVariant):
        for subVariant in SubVariant:
            i += 1
            # update_db(mainVariant, subVariant, mainVariant, str(i))
    else:
        delete_table_data(mainVariant, mainVariant, str(0))

        for subVariant in SubVariant:
            i += 1
            data = (mainVariant, subVariant, blob_value)
            insert_db(mainVariant, columnName, data)


except Error as e:
    print(e)
