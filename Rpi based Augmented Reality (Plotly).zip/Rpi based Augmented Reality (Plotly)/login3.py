# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\Logeshwaran\Downloads\NEW CERTIFICATES\AR 2.0\ui_userlogin.ui'
#
# Created by: PyQt5 UI code generator 5.15.9
#
# WARNING: Any manual changes made to this file will be lost when pyuic5 is
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from signup1 import Ui_Ui_Users
from resetpassword1 import Ui_Ui_ResetPassword
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QLabel, QWidget, QComboBox
from PyQt5.QtWidgets import QMessageBox
from PyQt5 import QtCore, QtGui, QtWidgets
from numpy import asarray
from numpy import savetxt
import MySQL_Queries
from PyQt5.QtWidgets import QListWidget
import Folder_Create
import cv2
import ROI_RW
import os
from AddVariantWindow import Ui_Add_Variant_Window
from overlaysample import Ui_MainWindow
#from voice1 import Ui_MainWindow
#from onlybuttons2 import Ui_OnlyButtons
########
import Folder_Create
import sys
import tkinter
import tkinter as tk
import tkinter.messagebox as messagebox
from tkinter import messagebox
from pathlib import Path
from PIL import Image
from PyQt5 import QtWidgets, QtGui
import configparser
import numpy as np
from tkinter import *
from tkinter import colorchooser
from pathlib import Path
from PIL import Image
from tkinter import filedialog
import pygame
import screeninfo
from tkinter import ttk
import time
import threading
from PyQt5.QtCore import Qt
from PyQt5.QtCore import QMetaObject, QObject, pyqtSignal
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QMessageBox
from PyQt5 import QtGui
import mysql.connector
import keyboard
import msvcrt
from datetime import datetime
#########################
import matplotlib.pyplot as plt
from matplotlib. backends. backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib. figure import Figure
from numpy import random
##################
Main_Folder_path = "C:/Users/Public/Documents/OpenCV/"
Main_Folder_Path ="C:/Users/Public/Documents/OpenCV/Setup/"
class Ui_Ui_UserLogin(QMainWindow):
    def setupUi(self, Ui_UserLogin):
        Ui_UserLogin.setObjectName("Ui_UserLogin")
        Ui_UserLogin.resize(851, 643)
        Ui_UserLogin.setMaximumSize(QtCore.QSize(851, 643))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("motherson_logo1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Ui_UserLogin.setWindowIcon(icon)
        self.centralwidget = QtWidgets.QWidget(Ui_UserLogin)
        self.centralwidget.setObjectName("centralwidget")
        self.line = QtWidgets.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(-3, 39, 941, 41))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(360, 20, 221, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(True)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.line_2 = QtWidgets.QFrame(self.centralwidget)
        self.line_2.setGeometry(QtCore.QRect(-3, 529, 861, 31))
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.pbexit = QtWidgets.QPushButton(self.centralwidget)
        self.pbexit.setGeometry(QtCore.QRect(730, 550, 100, 35))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.pbexit.setFont(font)
        self.pbexit.setObjectName("pbexit")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(260, 160, 151, 21))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(True)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(260, 220, 151, 21))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(True)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.leusername = QtWidgets.QLineEdit(self.centralwidget)
        self.leusername.setGeometry(QtCore.QRect(380, 160, 180, 30))
        self.leusername.setText("")
        self.leusername.setObjectName("leusername")
        self.lepassword = QtWidgets.QLineEdit(self.centralwidget)
        self.lepassword.setGeometry(QtCore.QRect(380, 220, 180, 30))
        #self.lepassword.setText("")
        self.lepassword.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lepassword.setObjectName("lepassword")
        self.pblogin = QtWidgets.QPushButton(self.centralwidget)
        self.pblogin.setGeometry(QtCore.QRect(310, 310, 185, 35))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.pblogin.setFont(font)
        self.pblogin.setObjectName("pblogin")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(280, 360, 151, 31))
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(False)
        # self.label_4.setFont(font)
        # self.label_4.setObjectName("label_4")
        # self.pbsignuphere = QtWidgets.QPushButton(self.centralwidget)
        # self.pbsignuphere.setGeometry(QtCore.QRect(430, 360, 120, 28))
        # self.pbsignuphere.setObjectName("pbsignuphere")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(320, 260, 121, 31))
        self.label_5.setObjectName("label_5")
        self.pbresethere = QtWidgets.QPushButton(self.centralwidget)
        self.pbresethere.setGeometry(QtCore.QRect(440, 260, 120, 28))
        self.pbresethere.setObjectName("pbresethere")
        Ui_UserLogin.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Ui_UserLogin)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 851, 26))
        self.menubar.setObjectName("menubar")
        Ui_UserLogin.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Ui_UserLogin)
        self.statusbar.setObjectName("statusbar")
        Ui_UserLogin.setStatusBar(self.statusbar)
        ################
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(10, 10, 151, 51))
        self.label_6.setText("")
        self.label_6.setPixmap(QtGui.QPixmap("Motherson-Logo2-transformed.ico"))
        self.label_6.setScaledContents(True)
        self.label_6.setObjectName("label_6")
        ################
        self.retranslateUi(Ui_UserLogin)
        QtCore.QMetaObject.connectSlotsByName(Ui_UserLogin)
        ###################
        self.pbresethere.pressed.connect(self.forgotpassword)
        #self.pbsignuphere.pressed.connect(self.register)
        self.pblogin.pressed.connect(self.matchdata)
        self.pbexit.pressed.connect(Ui_UserLogin.close) # type: ignore
        #################

    def matchdata(self):
        usernameentered = self.leusername.text()
        passwordentered = self.lepassword.text()
        userdata_config_path = os.path.join(Main_Folder_path, "UserData", "user_signupdata_config.ini")
        # Create necessary directories if they don't exist
        os.makedirs(os.path.dirname(userdata_config_path), exist_ok=True)
        config = configparser.ConfigParser()  # Create a ConfigParser object
        config.read(userdata_config_path)  # Read existing configuration file
        login_successful = False
        for section_name in config.sections():
            if (
                config.get(section_name, 'username') == usernameentered
                and config.get(section_name, 'password') == passwordentered
                and config.get(section_name, 'level') == 'Admin'
            ):
                login_successful = True
                break
        message_box = QMessageBox()
        message_box.setWindowTitle("Admin Login Status")
        if login_successful:
            print("Successfully Logged in as Admin")
            message_box.setIcon(QMessageBox.Information)
            message_text = "Successfully Logged in as Admin"
            #self.app = QtWidgets.QApplication(sys.argv)
            self.Ui_Users = QtWidgets.QMainWindow()
            self.ui = Ui_Ui_Users()
            self.ui.setupUi(self.Ui_Users)
            self.Ui_Users.show()
        else:
            print("Login failed! Try to Login as Admin")
            message_box.setIcon(QMessageBox.Warning)
            message_text = "Login failed - Login as Admin!"

        message_box.setText(message_text)

        # Set the icon for the QMessageBox
        icon = QIcon("motherson_logo1.png")
        message_box.setWindowIcon(icon)

        # Show the QMessageBox
        message_box.exec_()

    #def register(self):
        # self.app = QtWidgets.QApplication(sys.argv)
        # self.Ui_Users = QtWidgets.QMainWindow()
        # self.ui = Ui_Ui_Users()
        # self.ui.setupUi(self.Ui_Users)
        # self.Ui_Users.show()

    def forgotpassword(self):
        #self.app = QtWidgets.QApplication(sys.argv)
        self.Ui_ResetPassword = QtWidgets.QMainWindow()
        self.ui = Ui_Ui_ResetPassword()
        self.ui.setupUi(self.Ui_ResetPassword)
        self.Ui_ResetPassword.show()

    def retranslateUi(self, Ui_UserLogin):
        _translate = QtCore.QCoreApplication.translate
        Ui_UserLogin.setWindowTitle(_translate("Ui_UserLogin", "Motherson Automotive Technologies & Engineering"))
        self.label.setText(_translate("Ui_UserLogin", "Admin Login"))
        self.pbexit.setText(_translate("Ui_UserLogin", "Exit"))
        self.label_2.setText(_translate("Ui_UserLogin", "Username : "))
        self.label_3.setText(_translate("Ui_UserLogin", "Password : "))
        self.pblogin.setText(_translate("Ui_UserLogin", "Login"))
        self.label_5.setText(_translate("Ui_UserLogin", "Forgot Password?"))
        self.pbresethere.setText(_translate("Ui_UserLogin", "Reset Here!"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Ui_UserLogin = QtWidgets.QMainWindow()
    ui = Ui_Ui_UserLogin()
    ui.setupUi(Ui_UserLogin)
    Ui_UserLogin.show()
    sys.exit(app.exec_())
