#from imb8 import Ui_wMainWindow
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from resetpassword1 import Ui_Ui_ResetPassword
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QLabel, QWidget, QComboBox
from PyQt5 import QtCore, QtGui, QtWidgets
from numpy import asarray
from numpy import savetxt
import MySQL_Queries
from PyQt5.QtWidgets import QListWidget
import Folder_Create
import cv2
import ROI_RW
import os
#from AddVariantWindow import Ui_Add_Variant_Window
#from overlaysample import Ui_MainWindow
#from voice1 import Ui_hMainWindow
#from onlybuttons2 import Ui_OnlyButtons
########
import Folder_Create
import sys
import tkinter
import tkinter as tk
import tkinter.messagebox as messagebox
from tkinter import messagebox
from pathlib import Path
from PIL import Image
from PyQt5 import QtWidgets, QtGui
import configparser
import numpy as np
from tkinter import *
from tkinter import colorchooser
from pathlib import Path
from PIL import Image
from tkinter import filedialog
import pygame
import screeninfo
from tkinter import ttk
import time
import threading
from PyQt5.QtCore import Qt
from PyQt5.QtCore import QMetaObject, QObject, pyqtSignal
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5 import QtGui
import mysql.connector
import keyboard
import msvcrt
from datetime import datetime
#########################
import plotly.graph_objects as go
import plotly.io as pio
from PyQt5 import QtWidgets, QtCore, QtWebEngineWidgets
from numpy import random
##################
Main_Folder_path = "C:/Users/Public/Documents/OpenCV/"
Main_Folder_Path ="C:/Users/Public/Documents/OpenCV/Setup/"
userdata_config_path = os.path.join(Main_Folder_path, "UserData", "user_signupdata_config.ini")
config = configparser.ConfigParser()
config.read(userdata_config_path)
usernames = []
for section in config.sections():
    if 'username' in config[section]:
        username = config[section]['username']
        usernames.append(username)
class Ui_operator_efficiency(QtWidgets.QMainWindow):
    def setupUi(self, operator_efficiency):
        operator_efficiency.setObjectName("operator_efficiency")
        operator_efficiency.resize(1350, 850)
        operator_efficiency.setMaximumSize(QtCore.QSize(1350, 850))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("motherson_logo1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        operator_efficiency.setWindowIcon(icon)
        self.centralwidget = QtWidgets.QWidget(operator_efficiency)
        self.centralwidget.setObjectName("centralwidget")
        self.line = QtWidgets.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(-3, 60, 1361, 20))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.line_2 = QtWidgets.QFrame(self.centralwidget)
        self.line_2.setGeometry(QtCore.QRect(-3, 730, 1361, 20))
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.line_3 = QtWidgets.QFrame(self.centralwidget)
        self.line_3.setGeometry(QtCore.QRect(250, 70, 20, 671))
        self.line_3.setFrameShape(QtWidgets.QFrame.VLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(580, 20, 251, 31))
        font = QtGui.QFont()
        font.setPointSize(15)
        font.setBold(True)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(90, 90, 151, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(True)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        ##########################
        self.cbusers = QtWidgets.QComboBox(self.centralwidget)
        self.cbusers.setGeometry(QtCore.QRect(20, 120, 221, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        # font.setBold(True)
        self.cbusers.setFont(font)
        self.cbusers.setObjectName("cbusers")
        self.cbusers.addItems(usernames)
        #####################
        self.dateEdit = QtWidgets.QDateEdit(self.centralwidget)
        self.dateEdit.setGeometry(QtCore.QRect(1190, 140, 150, 30))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.dateEdit.setFont(font)
        self.dateEdit.setObjectName("dateEdit")
        self.pbshow = QtWidgets.QPushButton(self.centralwidget)
        self.pbshow.setGeometry(QtCore.QRect(1210, 190, 111, 35))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.pbshow.setFont(font)
        self.pbshow.setObjectName("pbshow")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(270, 80, 911, 651))
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        # Create a layout for the widget
        layout = QtWidgets.QVBoxLayout(self.frame)

        # Canvas Here - Use a QtWebEngineWidgets.QWebEngineView to display the Plotly figure
        self.canvas = QtWebEngineWidgets.QWebEngineView()
        layout.addWidget(self.canvas)

        # Add other widgets or customize the layout if needed
        self.pbexit = QtWidgets.QPushButton(self.centralwidget)
        self.pbexit.setGeometry(QtCore.QRect(1200, 760, 125, 40))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.pbexit.setFont(font)
        self.pbexit.setObjectName("pbexit")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(60, 190, 151, 51))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(True)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.cbMainVariant = QtWidgets.QComboBox(self.centralwidget)
        self.cbMainVariant.setGeometry(QtCore.QRect(20, 230, 221, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.cbMainVariant.setFont(font)
        self.cbMainVariant.setObjectName("cbMainVariant")
        self.dsbactualtime = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.dsbactualtime.setGeometry(QtCore.QRect(20, 330, 221, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.dsbactualtime.setFont(font)
        self.dsbactualtime.setObjectName("dsbactualtime")
        self.dsboperatorworking = QtWidgets.QDoubleSpinBox(self.centralwidget)
        self.dsboperatorworking.setGeometry(QtCore.QRect(20, 410, 221, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.dsboperatorworking.setFont(font)
        self.dsboperatorworking.setObjectName("dsboperatorworking")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(20, 300, 221, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(9)
        font.setBold(True)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(20, 380, 221, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(9)
        font.setBold(True)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(30, 470, 191, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        font.setBold(True)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.cbefficiencyselection = QtWidgets.QComboBox(self.centralwidget)
        self.cbefficiencyselection.setGeometry(QtCore.QRect(20, 500, 221, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(10)
        self.cbefficiencyselection.setFont(font)
        self.cbefficiencyselection.setObjectName("cbefficiencyselection")
        self.cbefficiencyselection.addItem("Overall Efficiency")
        self.cbefficiencyselection.addItem("Individual Cycle Efficiency")
        operator_efficiency.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(operator_efficiency)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1350, 26))
        self.menubar.setObjectName("menubar")
        operator_efficiency.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(operator_efficiency)
        self.statusbar.setObjectName("statusbar")
        operator_efficiency.setStatusBar(self.statusbar)
        ###########
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(10, 10, 151, 51))
        self.label_9.setText("")
        self.label_9.setPixmap(QtGui.QPixmap("Motherson-Logo2-transformed.ico"))
        self.label_9.setScaledContents(True)
        self.label_9.setObjectName("label_9")
        ###############
        self.retranslateUi(operator_efficiency)
        ###########
        self.pbexit.pressed.connect(operator_efficiency.close) # type: ignore
        self.pbshow.pressed.connect(self.efficiency_selection) # type: ignore
        ##########
        QtCore.QMetaObject.connectSlotsByName(operator_efficiency)
        ######################################
        Main_variants = MySQL_Queries.get_table_names()
        if Main_variants is not None and len(Main_variants) !=0:
            for variant in Main_variants:
                #self.lwMainVariantList.addItem(variant)
                self.lwMainVariantList = QListWidget()
                self.cbMainVariant.addItem(variant)

    def efficiency_selection(self):
        variant_name = self.cbMainVariant.currentText()
        selected_date = self.dateEdit.date().toString("dd-MM-yyyy")
        print(selected_date)
        date_folder_name = selected_date
        username = self.cbusers.currentText()
        config_path = os.path.join(Main_Folder_path, "traceability", date_folder_name, variant_name, username, "timer_config.ini")
        config = configparser.ConfigParser()
        config.read(config_path)
        selected = self.cbefficiencyselection.currentText()

        if selected == "Individual Cycle Efficiency":
            total_cycle_times = []
            for section in config.sections():
                if 'total cycle time' in config[section]:
                    total_cycle_time = float(config[section]['total cycle time'].split(':')[1].strip('s'))
                    total_cycle_times.append(total_cycle_time)
            values_individual_cycle_efficiency = [cycle_time / self.dsbactualtime.value() * 100 for cycle_time in total_cycle_times]
            print(values_individual_cycle_efficiency)

            colors = ['blue', 'brown', 'gold', 'red', 'green', 'teal']
            num_bars = len(values_individual_cycle_efficiency)
            color_indices = [i % len(colors) for i in range(num_bars)]
            bar_colors = [colors[idx] for idx in color_indices]

            fig = go.Figure(data=[go.Bar(x=list(range(1, len(values_individual_cycle_efficiency) + 1)),
                                        y=values_individual_cycle_efficiency,
                                        marker=dict(color=bar_colors),
                                        )])
            fig.update_layout(title=f"<b>Bar chart representing the Individual Cycle Efficiency of User: {username}<b>",
                            yaxis_title="<b>Efficiency (%)<b>",
                            showlegend=False)

        elif selected == "Overall Efficiency":
            total_cycle_times = []
            for section in config.sections():
                if 'total cycle time' in config[section]:
                    total_cycle_time = float(config[section]['total cycle time'].split(':')[1].strip('s'))
                    total_cycle_times.append(total_cycle_time)
            values_overall_efficiency = sum(total_cycle_times) / self.dsboperatorworking.value() * 100
            print(values_overall_efficiency)

            colors = ['blue', 'brown', 'gold', 'red', 'green', 'teal']
            num_bars = 1  # For overall efficiency, we only have one value.
            color_indices = [i % len(colors) for i in range(num_bars)]
            bar_colors = [colors[idx] for idx in color_indices]

            fig = go.Figure(data=[go.Bar(x=['Overall Efficiency'],
                                        y=[values_overall_efficiency],
                                        marker=dict(color=bar_colors),
                                        )])
            fig.update_layout(title=f"<b>Bar chart representing the Overall Efficiency of User: {username}<b>",
                            yaxis_title="<b>Efficiency (%)<b>",
                            showlegend=False)

        else:
            print("No Input Found")

        # Render the Plotly figure in the QtWebEngineView
        html_content = pio.to_html(fig, include_plotlyjs='cdn')
        self.canvas.setHtml(html_content)

    def retranslateUi(self, operator_efficiency):
        _translate = QtCore.QCoreApplication.translate
        operator_efficiency.setWindowTitle(_translate("operator_efficiency", "Motherson Automotive Technologies & Engineering"))
        self.label.setText(_translate("operator_efficiency", "Operator Efficiency"))
        self.label_2.setText(_translate("operator_efficiency", "Users"))
        self.pbshow.setText(_translate("operator_efficiency", "Show"))
        self.pbexit.setText(_translate("operator_efficiency", "Exit"))
        self.label_3.setText(_translate("operator_efficiency", "Main Variants"))
        self.label_4.setText(_translate("operator_efficiency", "Actual Cycle Time / Cycle (Sec)"))
        self.label_5.setText(_translate("operator_efficiency", "Operator Working Hours (Sec)"))
        self.label_6.setText(_translate("operator_efficiency", "Efficiency Selection"))
        self.cbefficiencyselection.setItemText(0, _translate("operator_efficiency", "Overall Efficiency"))
        self.cbefficiencyselection.setItemText(1, _translate("operator_efficiency", "Individual Cycle Efficiency"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    operator_efficiency = QtWidgets.QMainWindow()
    ui = Ui_operator_efficiency()
    ui.setupUi(operator_efficiency)
    operator_efficiency.show()
    sys.exit(app.exec_())